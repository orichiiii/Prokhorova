﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Freshmaker
{
    public class Fresh
    {
        public string Name;
        public int Price;

        public Fresh(string name, int price)
        {
            Name = name;
            Price = price;
        }
    }
}
