﻿using System;

namespace Task2
{
    class Task2
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.Unicode;
            Console.InputEncoding = System.Text.Encoding.Unicode;
            int[] myArray = new int[5] { 2, 5, 7, 13, 24 };
            for (int i = myArray.Length - 1; i >= 0; i--)
            {
                Console.WriteLine(myArray[i]);
            }

        }
    }
}
