﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task1
{
    public class Product
    {
        public string Name { get; }  
        public int Price { get; }
        public int Quantity { get; set; }

        public Product(string name, int price, int quanity)
        {
            Name = name;
            Price = price;
            Quantity = quanity;
        }
    }
}
