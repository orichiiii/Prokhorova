﻿using System;
using System.Collections.Generic;

namespace Task1
{
    internal class Program : Store
    {
        //Имеется магазин с продуктами, менеджер может добавлять и удалять продукты из склада, также может видеть весь список товаров
        //Покупатель, имеет 50$ на покупки, он может только покупать товары и просматривать весь перечень,
        //примерный вид Название| Цена, $| Кол-во|,
        //он может покупать определенное кол-во товаров, если его больше чем один.Стартовый набор товаров должен быть не менее 10.

        public static void Main()
        {
            Customer customer = new Customer();
            Store.DefaultProduct();
            Store.ValidateUser(customer);
            if (!IsManager)
            {
                while (true)
                    Store.CustomerFunctional(customer);
            }
            else
                while (true)
                    Store.ManagerFunctional();
        }
    }
}
