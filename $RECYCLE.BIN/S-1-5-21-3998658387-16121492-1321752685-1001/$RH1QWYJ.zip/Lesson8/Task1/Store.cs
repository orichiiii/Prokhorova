﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Task1
{
    public class Store
    {
        public static bool IsManager;
        public static List<Product> Products = new List<Product>();

        public static void DefaultProduct()
        {
            Products.Add(new Product("rose", 6, 10));
            Products.Add(new Product("carnation", 3, 5));
            Products.Add(new Product("hydrangea", 8, 20));
            Products.Add(new Product("bluebell", 1, 15));
            Products.Add(new Product("lily", 6, 4));
            Products.Add(new Product("peony", 7, 22));
            Products.Add(new Product("chrysanthemum", 3, 12));
            Products.Add(new Product("tulip", 6, 10));
            Products.Add(new Product("sunflower", 9, 3));
            Products.Add(new Product("orchid", 30, 2));
        }

        public static void ValidateUser(Customer customer)
        {
            WriteLine("Please, enetr (1) if you are a customer, (2) if you are a manager: ");
            var userInitialization = ReadLine();

            switch (userInitialization)
            {
                case "1": CustomerFunctional(customer); break;
                case "2": IsUserManager(); break;
                default: throw new ArgumentException($"Invalid operation {userInitialization}.");
            }
        }

        public static void CustomerFunctional(Customer customer)
        {
            IsManager = false;

            Write($"You have {customer.Cash}$. Please choose the action: (1)Show all products, (2)Buy product: ");
            var customerOperation = ReadLine();

            switch (customerOperation)
            {
                case "1": ShowAllGoods(); break;
                case "2": BuyProduct(customer); break;
                default: throw new ArgumentException($"Invalid operation {customerOperation}.");
            }

        }

        private static void BuyProduct(Customer customer)
        {
            WriteLine("Please, enter the name of the product you want to buy: ");
            var productName = ReadLine();

            var selectedProduct = Products.Find(x => x.Name == productName);
            if (Products.Contains(selectedProduct) & selectedProduct.Quantity > 1)
            {
                int productQuantity;
                ProductData(selectedProduct, out productQuantity);
                Purchase(customer, selectedProduct, productQuantity);
            }
            else
                WriteLine($"{productName} does not exist in our store.");
        }

        private static void Purchase(Customer customer, Product selectedProduct, int productQuantity)
        {
            if (customer.Cash == selectedProduct.Price * productQuantity)
            {
                selectedProduct.Quantity -= productQuantity;
                customer.Cash -= selectedProduct.Price * productQuantity;
                WriteLine("You have successfully purchased this item.");
            }
            else
                WriteLine("you don't have enough money.");
        }

        private static void ProductData(Product product, out int productQuantity)
        {
            string quantity;

            while (true)
            {
                Write($"Enter the quantity of the product you want to buy (Quantity at the moment {product.Quantity}, price {product.Price}): ");
                quantity = ReadLine();

                if (int.TryParse(quantity, out productQuantity))
                {
                    break;
                }
                else
                    WriteLine("You entered incorrect data.");
            }
        }

        private static void IsUserManager()
        {
            while (true)
            {
                Write("Please enter the login: ");
                var login = ReadLine();

                Write("Please enter the password: ");
                var password = ReadLine();

                if (login == "admin" & password == "admin")
                {
                    WriteLine("You have successfully logged in!");
                    IsManager = true;
                    break;
                }
                else
                    WriteLine("You entered incorrect data.");
            }
            ManagerFunctional();
        }

        public static void ManagerFunctional()
        {
            Write("Please choose the action: (1)Show all products, (2)Add new product, (3)Delete product: ");
            var managerOperation = ReadLine();

            switch (managerOperation)
            {
                case "1": ShowAllGoods(); break;
                case "2": AddNewProduct(); break;
                case "3": DeleteProduct(); break;
                default: throw new ArgumentException($"Invalid operation {managerOperation}.");
            }
        }

        private static void DeleteProduct()
        {
            WriteLine("Please enter the name of the product you want to add: ");
            var productName = ReadLine();

            var selectedProduct = Products.Find(x => x.Name == productName);

            if (Products.Remove(selectedProduct))
                WriteLine($"{productName} has been successfully removed from the book catalog");
            else
                WriteLine($"{productName} does not exist in the catalog.");
        }

        private static void ShowAllGoods()
        {
            if (Products.Count == 0)
                WriteLine("Product catalog is empty.");

            else
            {
                WriteLine("Name | Price | Quantity");
                foreach (var Product in Products)
                    WriteLine($"{Product.Name} | {Product.Price} | {Product.Quantity}");
            }
        }

        private static void AddNewProduct()
        {
            WriteLine("Please enter the name of the product you want to add: ");
            var productName = ReadLine();

            int productPrice;
            int productQuantity;
            while (true)
            {
                WriteLine("Please enter the price of the product you want to add: ");
                var price = ReadLine();

                WriteLine("Please enter the quantity of the product you want to add: ");
                var quantity = ReadLine();
                if (int.TryParse(price, out productPrice) & int.TryParse(quantity, out productQuantity))
                    break;
                else
                    WriteLine("You entered incorrect data.");
            }

            Products.Add(new Product(productName, productPrice, productQuantity));
            WriteLine("the product has been successfully added to the catalog.");
        }

    }
}
