﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Freshmaker
{
    public class Customer
    {
        public int Cash = 100;
        public int CreditCard = 100;

        public static Customer customer = new Customer();

        public static void ChooseTaste()
        {
            WriteLine("\n Please choose the taste of fresh (enter name): \n");
            Freshmaker.ShowMenu();
            var userChoice = ReadLine();

            var selectedFresh = Freshmaker.menu.Find(x => x.Name == userChoice);
            if (Freshmaker.menu.Contains(selectedFresh))
            {
                Freshmaker.CookFromMenu(selectedFresh);
                Purchase(selectedFresh);
            }
            else
                WriteLine($"{userChoice} fresh does not exist in our store.");

        }

        private static void Purchase(Fresh selectedFresh)
        {
            WriteLine("Please choose payment method: (1)Cash, (2)Credit Card");
            var userPayment = ReadLine();

            switch (userPayment)
            {
                case "1": PayCash(selectedFresh); break;
                case "2": PayCreditCard(selectedFresh); break;
                default: throw new ArgumentException($"Invalid operation {userPayment}");
            }
        }

        public static void PayCash(Fresh selectedFresh)
        {
            customer.Cash -= selectedFresh.Price;
            WriteLine($"Thank you for Purchase. Your balance is {customer.Cash}");
        }

        public static void PayCreditCard(Fresh selectedFresh)
        {
            customer.CreditCard -= selectedFresh.Price;
            WriteLine($"Thank you for Purchase. Your balance is {customer.Cash}");
        }
    }
}
