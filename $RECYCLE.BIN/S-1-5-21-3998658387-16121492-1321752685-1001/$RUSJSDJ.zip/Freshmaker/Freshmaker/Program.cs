﻿using System;

namespace Freshmaker
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Customer.ChooseTaste();
            }
        }
    }
}
