﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Freshmaker
{
    public class Freshmaker
    {
        public static readonly List<Fresh> menu = new List<Fresh>
        {
            new Fresh ("Mango", 45),
            new Fresh ("Apple", 20),
            new Fresh ("Watermelon", 60),
            new Fresh ("Peach", 30),
            new Fresh ("Melon", 32),
        };

        public static void CookFromMenu(Fresh fresh)
        {
            WriteLine($"I cooked fresh {fresh.Name} for you.");
        }

        public static void ShowMenu()
        {
            var i = 1;

            WriteLine("Name | Price");

            foreach (Fresh fresh in menu)
            {
                WriteLine($"{i} {fresh.Name} | {fresh.Price}");
                i++;
            }

        }
    }
}
