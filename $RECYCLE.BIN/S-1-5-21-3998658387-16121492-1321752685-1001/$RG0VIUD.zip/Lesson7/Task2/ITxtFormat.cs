﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Task2
{
    interface ITxtFormat
    {
        public static void GetText()
        {

        }
        public static void StringFormat(string userText)
        {

        }
    }
}
