﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lesson7
{
    public abstract class Transformer
    {
        protected readonly Weapon Weapon;
        protected readonly Scanner Scanner;
        protected bool IsTransformed;

        protected Transformer(Weapon weapon, Scanner scanner)
        {
            Weapon = weapon;
            Scanner = scanner;
        }

        public abstract void Fire();
        public abstract void Run();
        public abstract void FindEnemy();
        public abstract void Transform();
    }
}
