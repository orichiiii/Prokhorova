﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Lesson7
{
    public class Bumblbee : SwimmingTransformer
    {
        public Bumblbee(Weapon weapon, Scanner scanner) : base(weapon, scanner) { }

        public override void Transform()
        {
            if (!IsTransformed)
            {
                WriteLine("Transforming into a robot.");
                IsTransformed = true;
            }
        }

        public override void Run()
        {
            WriteLine("I am running.");
        }

        public override void FindEnemy()
        {
            Scanner.Scan();
        }

        public override void Fire()
        {
            Weapon.Fire();
        }

        public override void Swim()
        {
            if (IsTransformed)
                IsTransformed = false;

            WriteLine("Transformation into a yacht.");
        }
    }
}
