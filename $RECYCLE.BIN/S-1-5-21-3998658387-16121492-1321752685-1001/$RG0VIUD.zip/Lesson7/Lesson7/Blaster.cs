﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Lesson7
{
    public class Blaster : Weapon
    {
        public override void Reload()
        {
            Ammo += 6;
            WriteLine("I am recharging the blaster. The weapon now has 6 charges.");
        }
        public override void Fire()
        {
            WriteLine("I am shooting a laser.");
        }
    }
}
