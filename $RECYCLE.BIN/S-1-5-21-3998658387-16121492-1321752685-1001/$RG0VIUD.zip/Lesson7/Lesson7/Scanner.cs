﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lesson7
{
    public abstract class Scanner
    {
        public abstract void Scan();
    }
}
