﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lesson7
{
    public abstract class Weapon
    {
        protected int Ammo = 0;

        public abstract void Reload();
        public abstract void Fire();
    }
}
