﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Lesson7
{
    public class OptimusPrime : DriverTransformer
    {
        public OptimusPrime(Weapon weapon, Scanner scanner) : base(weapon, scanner) { }

        public override void Fire()
        {
            Weapon.Fire();
        }

        public override void Run()
        {
            if (IsTransformed)
            {
                WriteLine("Transforming into a car.");
                IsTransformed = false;
            }
        }

        public override void FindEnemy()
        {
            Scanner.Scan();
        }

        public override void Transform()
        {
            if (IsTransformed)
            {
                WriteLine("Transforming into a car.");
                IsTransformed = false;
            }
        }

        public override void Drive()
        {
            if (IsTransformed)
                IsTransformed = false;

            WriteLine("Transformation into a car.");
        }
    }
}
