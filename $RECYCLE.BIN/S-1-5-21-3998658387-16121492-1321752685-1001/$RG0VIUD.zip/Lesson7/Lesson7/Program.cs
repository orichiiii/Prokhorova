﻿using Lesson7;
using System;
using static System.Console;

namespace Transformers
{
    internal class Program
    {
        //Предположим, что существует три типа трансформеров(конкретным трансформерам можете давать свои произвольные имена),
        //которые умеют плавать, летать и ездить в состоянии когда они транспорт, и также все они могут стрелять и бегать,
        //когда превращены в трансформеров.Также у каждого подтипа есть свой способ искать противника
        //при помощи сканера, у водяного это эхолокатор, у назвемного оптический сканер, а у того, что летает - это сканер свой-чужой,
        //все они используя этот сканер могут находить врагов.
        //Создать этих трансформеров и имплементировать(имплементация типа - вывести сообщение в консоль.) все их действия,
        //использовать интерфейсы и классы для реализации данной задачи)
        private static void Main()
        {
            var optimusPrime = new OptimusPrime(new LaserWeapon(), new OpticalScanner());
            var bumblbee = new Bumblbee(new Blaster(), new Sonar());

            WriteLine("Bumblbee:");

            bumblbee.Transform();
            bumblbee.FindEnemy();
            bumblbee.Run();
            bumblbee.Fire();
            bumblbee.Swim();

            WriteLine("\n Optimus Prime:");

            optimusPrime.Transform();
            optimusPrime.FindEnemy();
            optimusPrime.Run();
            optimusPrime.Fire();
            optimusPrime.Drive();
        }
    }
}