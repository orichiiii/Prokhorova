﻿using System;

namespace Task5
{
    class Program
    {
        //Реализовать функции изменения для ссылочных типов внутри значимых типов.

        static void Main(string[] args)
        {
            Struct struct1 = new Struct();
            struct1.bbb = struct1.ddd;
        }

        public struct Struct
        {
            public Class bbb;
            public Class ddd;
        }

        public class Class
        {
        }
    }
}
