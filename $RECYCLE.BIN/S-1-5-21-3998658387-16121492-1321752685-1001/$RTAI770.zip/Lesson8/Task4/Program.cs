﻿using System;

namespace Task4
{
    class Program
    {
        //Реализовать функции изменения значимых и ссылочных типов данных для составных типов.

        static void Main(string[] args)
        {
            Fruits apple = new Fruits();
            Vegetables potatoes = new Vegetables();
            apple = potatoes.watermelon;
            
        }

        public struct Fruits
        {
            public string apple;
        }
        public class Vegetables
        {
            public string potatoes;
            public Fruits watermelon;
        }
    }
}
