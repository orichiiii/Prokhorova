﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Task11
{
    class Product
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public int Quantity { get; set; }

        public Product(string name, int price, int quantity)
        {
            Name = name;
            Price = price;
            Quantity = quantity;
        }
    }
}
