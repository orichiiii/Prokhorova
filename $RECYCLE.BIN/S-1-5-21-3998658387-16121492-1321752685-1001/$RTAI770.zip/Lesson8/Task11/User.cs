﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Task11
{
    public abstract class User
    {
        public static bool IsManager;

        public static void ShowAllProducts()
        {
            if (Store.Products.Count == 0)
                WriteLine("Product catalog is empty.");
            else
            {
                WriteLine("Name | Price | Quantity");
                foreach (var Product in Store.Products)
                    WriteLine($"{Product.Name} | {Product.Price} | {Product.Quantity}");
            }
        }

        protected void LeaveTheStore()
        {
            Write("Do you want to leave the store? (1)yes, (2)no: ");
            var userChoice = ReadLine();
            if (userChoice == "1")
            {

            }
        }
    }
}
