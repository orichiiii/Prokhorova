﻿using System;
using static System.Console;

namespace Task11
{
    internal class Program
    {
        public static Customer customer = new Customer();

        static void Main()
        {
            ValidateUser();
            if (!User.IsManager)
            {
                while (true)
                    CustomerFunctional();
            }
            else
                while (true)
                    ManagerFunctional();
        }

        public static void ValidateUser()
        {
            WriteLine("Please, enter (1) if you are a customer, (2) if you are a manager: ");
            var userInitialization = ReadLine();

            switch (userInitialization)
            {
                case "1": CustomerFunctional(); break;
                case "2": IsUserManager(); break;
                default: throw new ArgumentException($"Invalid operation {userInitialization}.");
            }
        }

        public static void CustomerFunctional()
        {
            User.IsManager = false;

            Write($"You have {customer.Cash}$. Please choose the action: (1)Show all products, (2)Buy product: ");
            var customerOperation = ReadLine();

            switch (customerOperation)
            {
                case "1": User.ShowAllProducts(); break;
                case "2": Customer.BuyProduct(); break;
                default: throw new ArgumentException($"Invalid operation {customerOperation}.");
            }

        }

        private static void IsUserManager()
        {
            while (true)
            {
                Write("Please enter the login: ");
                var login = ReadLine();

                Write("Please enter the password: ");
                var password = ReadLine();

                if (login == "admin" & password == "admin")
                {
                    WriteLine("You have successfully logged in!");
                    break;
                }
                else
                    WriteLine("You entered incorrect data.");
            }
            ManagerFunctional();
        }

        public static void ManagerFunctional()
        {
            User.IsManager = true;
            Write("Please choose the action: (1)Show all products, (2)Add new product, (3)Delete product: ");
            var managerOperation = ReadLine();

            switch (managerOperation)
            {
                case "1": User.ShowAllProducts(); break;
                case "2": Manager.AddNewProduct(); break;
                case "3": Manager.DeleteProduct(); break;
                default: throw new ArgumentException($"Invalid operation {managerOperation}.");
            }
        }
    }
}
