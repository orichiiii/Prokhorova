﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Task11
{
    class Store
    {
        public static List<Product> Products = new List<Product>()
        {
            new Product("rose", 6, 10),
            new Product("carnation", 3, 5),
            new Product("hydrangea", 8, 20),
            new Product("bluebell", 1, 8),
            new Product("lily", 6, 4),
            new Product("peony", 7, 22),
            new Product("chrysanthemum", 3, 12),
            new Product("tulip", 6, 10),
            new Product("sunflower", 9, 3),
            new Product("orchid", 30, 16)
        };
    }
}
