﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Task11
{
    class Manager : User
    {
        public static void DeleteProduct()
        {
            WriteLine("Please enter the name of the product you want to add: ");
            var productName = ReadLine();

            var selectedProduct = Store.Products.Find(x => x.Name == productName);

            if (Store.Products.Remove(selectedProduct))
                WriteLine($"{productName} has been successfully removed from the book catalog");
            else
                WriteLine($"{productName} does not exist in the catalog.");
        }

        public static void AddNewProduct()
        {
            WriteLine("Please enter the name of the product you want to add: ");
            var productName = ReadLine();

            int productPrice;
            int productQuantity;
            while (true)
            {
                WriteLine("Please enter the price of the product you want to add: ");
                var price = ReadLine();

                WriteLine("Please enter the quantity of the product you want to add: ");
                var quantity = ReadLine();
                if (int.TryParse(price, out productPrice) & int.TryParse(quantity, out productQuantity))
                    break;
                else
                    WriteLine("You entered incorrect data.");

                Store.Products.Add(new Product(productName, productPrice, productQuantity));
                WriteLine("the product has been successfully added to the catalog.");
            }
        }
    }
}
