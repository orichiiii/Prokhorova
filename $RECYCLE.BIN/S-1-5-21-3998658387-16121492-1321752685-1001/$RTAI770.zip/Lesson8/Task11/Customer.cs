﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Task11
{
    class Customer : User
    {
        public int Cash { get; set; } = 50;

        public static void BuyProduct()
        {
            WriteLine("Please, enter the name of the product you want to buy: ");
            var productName = ReadLine();

            var selectedProduct = Store.Products.Find(x => x.Name == productName);
            if (Store.Products.Contains(selectedProduct) &  selectedProduct.Quantity >= 1)
            {
                GetProductData(selectedProduct, out int productQuantity);
                Purchase(selectedProduct, productQuantity);
            }
            else
                WriteLine($"{productName} does not exist in our store.");
        }

        private static void GetProductData(Product product, out int productQuantity)
        {
            string quantity;

            while (true)
            {
                Write($"Enter the quantity of the product you want to buy (Quantity at the moment {product.Quantity}, price {product.Price}): ");
                quantity = ReadLine();

                if (int.TryParse(quantity, out productQuantity))
                {
                    break;
                }
                else
                    WriteLine("You entered incorrect data.");
            }
        }

        private static void Purchase(Product selectedProduct, int productQuantity)
        {
            if (Program.customer.Cash >= selectedProduct.Price * productQuantity)
            {
                selectedProduct.Quantity -= productQuantity;
                Program.customer.Cash -= selectedProduct.Price * productQuantity;
                WriteLine("You have successfully purchased this item.");
            }
            else
                WriteLine("you don't have enough money.");
        }
    }
}
