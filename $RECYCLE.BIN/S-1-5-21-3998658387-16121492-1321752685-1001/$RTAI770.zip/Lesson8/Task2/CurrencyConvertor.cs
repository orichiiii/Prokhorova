﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Task2
{
    internal class CurrencyConvertor
    {
        public static List<Currency> currencies = new List<Currency>()
        {
            new Currency("USD", 27.939),
            new Currency("RUB", 0.3656),
            new Currency("EUR", 32.8632),
            new Currency("PLN", 7.1651),
            new Currency("JPY", 0.2529)
        };

        public static void ConvertCurrnecy(string convertTo, string convertFrom, double amountOfMoney)
        {
            var selectedCurrencyTo = CurrencyConvertor.currencies.Find(x => x.Name == convertTo);
            var selectedCurrencyFrom = CurrencyConvertor.currencies.Find(x => x.Name == convertFrom);
            if (CurrencyConvertor.currencies.Contains(selectedCurrencyTo) & CurrencyConvertor.currencies.Contains(selectedCurrencyFrom))
            {
                WriteLine($"{amountOfMoney * selectedCurrencyFrom.Rate / selectedCurrencyTo.Rate}");
            }
            else
                WriteLine($"There is no such currency in our catalog.");
        }
    }
}
