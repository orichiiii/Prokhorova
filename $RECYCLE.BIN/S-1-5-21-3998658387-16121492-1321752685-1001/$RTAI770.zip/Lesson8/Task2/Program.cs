﻿using System;
using System.Collections.Generic;
using static System.Console;

namespace Task2
{
    internal class Program
    {
        //Написать программу "Конвертор валют". Программа должна поддерживать не менее 5 валют,
        //Конвертация должна быть доступна из любой валюты в любую.
        //Пару валют и сумму для конвертации указывает пользователь.
        //Rate валют можете брать тот, что сейчас на текущий момент, решить с использованием классов,
        //предусмотреть все негативные кейсы, не нужно использовать реальные rates в runtime!)
        public static void Main()
        {
            while (true)
            {
                GetData();
            }
        }

        public static void GetData()
        {
            Write("Please enter the currency you want to convert to (USD, RUB, JPY, PLN, EUR): ");
            var currencyTo = ReadLine();

            Write(" From (USD, RUB, JPY, PLN, EUR): ");
            var currencyFrom = ReadLine();

            ValidateMoney(out double userMoney);

            CurrencyConvertor.ConvertCurrnecy(currencyTo, currencyFrom, userMoney);
        }

        public static void ValidateMoney(out double userMoney)
        {
            string money;

            while (true)
            {
                Write("Enter the amount you want to change:: ");
                money = ReadLine();

                if (double.TryParse(money, out userMoney))
                {
                    break;
                }
                else
                    WriteLine("You entered incorrect data.");
            }
        }
    }
}
