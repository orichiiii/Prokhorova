﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task2
{
    public class Currency
    {
        public string Name { get; set; }
        public double Rate { get; set; }

        public Currency(string name, double rate)
        {
            Name = name;
            Rate = rate;
        }
    }
}
