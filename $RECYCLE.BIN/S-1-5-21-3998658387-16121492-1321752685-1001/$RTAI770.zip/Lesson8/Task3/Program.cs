﻿using System;
using static System.Console;

namespace Task3
{
    internal class Program
    {
        //Реализовать функции изменения значимых и ссылочных типов данных.

        public static void Main()
        {
            int a = 10;
            int b;
            b = a;
            WriteLine($"{b / 2}; {a}");

            string hello = "Hello";
            string nthng = hello;
            hello = "Bye";
            WriteLine($"{hello}; {nthng}");
        }
    }
}
