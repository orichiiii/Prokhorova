﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Task1
{
    public class Customer
    {
        public int Cash { get; set; } = 50;
    }
}
