﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Snake
{
    class PlayingField
    {
        public int[,] Field = new int[6, 6] { { 1, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0 } };
        public int X;
        public int Y;
        public int Snakecoordinates;

        public void CreateFruit(Food.fruits fruit)
        {
            Random x = new Random();
            x.Next(0, 6);

            X = x.Next(0, 6);
        }
    }
}
