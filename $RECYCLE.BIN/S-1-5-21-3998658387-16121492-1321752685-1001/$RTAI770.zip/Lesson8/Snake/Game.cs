﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Snake
{
    class Game
    {
        public static void ChooseAction()
        {
            WriteLine("Please choose yhe action: (1) Show all scores, (2) Start game, (3) Exit game, (4)Create new player, (5) Delete player, (6) Select player: ");
            var userChoice = ReadLine();

            switch (userChoice)
            {
                case "1": PlayersBase.ShowAllScores(); break;
                case "2": Player.ChangeDirection(); break;
                case "3": ExitGame(); break;
                case "4": CreateNewPlayer(); break;
                case "5": DeletePlayer(); break;
                case "6": SelectPlayer(); break;
                default:
                    break;
            }
        }

        private static void DeletePlayer()
        {
            Write("Enter name: ");
            var playerName = ReadLine();



            if (PlayersBase._playersBase.Remove(playerName))
            {

            }

        }

        private static void CreateNewPlayer()
        {
            Write("Enter your name: ");
            var playerName = ReadLine();

            Player player = new Player(playerName);

            PlayersBase._playersBase.Add(player);
        }
    }
}
