﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Snake
{
    class Snake
    {
        public static int Size;
        public static string Direction;

        public Snake()
        {

        }

        public static void TakeAStep(string direction)
        {
            switch (direction)
            {
                case "1": WriteLine($"The snake moves forward"); break;
                case "2": WriteLine($"The snake moves backward"); break;
                case "3": WriteLine($"The snake moves right"); break;
                case "4": WriteLine($"The snake moves left"); break;
                default: WriteLine("The snake does not know this direction.");
                    break;
            }
        }

        public static void EatFruits()
        {

        }
    }
}
