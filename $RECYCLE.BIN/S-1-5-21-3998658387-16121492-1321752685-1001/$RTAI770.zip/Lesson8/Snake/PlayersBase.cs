﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Snake
{
    class PlayersBase
    {
        public static readonly List<Player> _playersBase = new List<Player>();

        public void ShowAllScores()
        {
            foreach (var players in _playersBase)
            {
                WriteLine(players);
            }
        }


    }
}
