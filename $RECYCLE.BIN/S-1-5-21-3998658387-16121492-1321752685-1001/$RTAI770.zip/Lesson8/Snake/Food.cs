﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Snake
{
    class Food
    {
        public enum fruits
        {
            Apple,
            Pear,
            Raspberry,
            Strawberry
        }
    }
}
