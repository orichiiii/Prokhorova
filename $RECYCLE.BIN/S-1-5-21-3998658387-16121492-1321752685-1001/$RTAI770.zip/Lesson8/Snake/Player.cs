﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Snake
{
    class Player
    {
        protected string Name;
        protected int Score;

        public Player(string name)
        {
            Name = name;
        }

        public static void ChangeDirection()
        {
            WriteLine("Choose direction: (1) forward, (2) backward, (3) right, (4) left.");
            var direction = ReadLine();

            Snake.TakeAStep(direction);
        }

        private static void EndGame()
        {

        }
    }
}
