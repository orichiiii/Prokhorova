﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Task1
{
    internal class BankSystem
    {
        private static readonly Dictionary<string, string> _users = new Dictionary<string, string> { { "admin", "admin" }, { "system", "system" } };
        public static bool IsLogin;

        public static void ChooseAction()
        {
            Write("\n The bank welcomes you! Please choose the action:\n(1) Registration, (2) Login: ");
            var userOperation = ReadLine();

            switch (userOperation)
            {
                case "1": Registration(); break;
                case "2": Login(); break;
                default: throw new ArgumentException($"Invalid operation {userOperation}.");
            }
        }

        private static bool IsLoginExist(string login)
        {
            var result = _users.Keys.Any(key => key.Equals(login));

            if (!result)
                WriteLine($"User with login {login} does not exist in the system.");

            return result;
        }

        public static void Registration()
        {
            if (!IsLogin)
            {
                WriteLine("Please, enter the login:");
                var login = ReadLine();

                WriteLine("Please, enter the password:");
                var password = ReadLine();

                if (!_users.TryAdd(login, password))
                    WriteLine($"User with login {login} already exists.");
                else
                {
                    WriteLine($"You have been successfully registered in the system as user with login {login}.");
                    Login();
                }
            }
            else
                WriteLine("You are already logged in the system.");
        }

        private static bool ValidateLogin(ref string login)
        {
            while (!IsLoginExist(login))
            {
                WriteLine("Do you want try again? Y/N");
                if (ReadLine().ToLower() == "y")
                {
                    WriteLine("Please, enter your login again:");
                    login = ReadLine();
                }
                else
                    return false;
            }

            return true;
        }

        private static bool IsPasswordCorrect(string login, string password)
        {
            var result = _users[login].Equals(password);

            if (!result)
                WriteLine("Password is incorrect.");

            return result;
        }

        private static bool ValidatePassword(string login, string password)
        {
            while (!IsPasswordCorrect(login, password))
            {
                WriteLine("Do you want try again? Y/N");
                if (ReadLine().ToLower() == "y")
                {
                    WriteLine("Please, enter your password again:");
                    password = ReadLine();
                }
                else
                    return false;
            }

            return true;
        }

        public static void Login()
        {
            if (!IsLogin)
            {
                WriteLine("Please, enter your login:");
                var login = ReadLine();
                if (!ValidateLogin(ref login))
                    return;

                WriteLine("Please, enter the password.");
                var password = ReadLine();

                if (!ValidatePassword(login, password))
                    return;

                    WriteLine($"You have been successfully logged in the system as user with login {login}.");
                IsLogin = true;
            }
            else
                WriteLine("You are logged in the system.");
        }

        public static void Logout()
        {
            if (IsLogin)
            {
                WriteLine("You are successfully logout from the system.");
                IsLogin = false;
            }
            else
                WriteLine("You are not logged in the system.");
        }
    }
}
