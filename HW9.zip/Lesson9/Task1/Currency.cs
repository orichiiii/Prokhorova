﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task1
{
    class Currency
    {
        public string Name;
        public double Rate;

        public Currency(string name, double rate)
        {
            Name = name;
            Rate = rate;
        }
    }
}
