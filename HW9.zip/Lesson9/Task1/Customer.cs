﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Task1
{
    class Customer
    {
        public static List<Wallet> Wallets = new List<Wallet>
        {
            new Wallet (new Currency("USD", 27.939), 100),
            new Wallet(new Currency("EUR", 32.8632), 30)
        };

        public static void ChooseActionCustomer()
        {
            Write("\nThe bank welcomes you! Please choose the action:\n(1) Add money account, (2) Top up account, (3) Withdraw money, (4) Convert money, (5) Show Exchange Rates (6)Logout: ");
            var userOperation = ReadLine();

            switch (userOperation)
            {
                case "1": CreateMoneyAccount(); break;
                case "2": TopUpAccount(); break;
                case "3": WithdrawMoney(); break;
                case "4": ConvertMoney(); break;
                case "6": BankSystem.Logout(); break;
                case "5": CurrencyConvertor.ShowAllRates(); break;
                default: throw new ArgumentException($"Invalid operation {userOperation}.");
            }
        }

        private static void ConvertMoney()
        {
            Write("Please enter the currency you want to convert to (USD, RUB, UAH, CHY, EUR): ");
            var currencyTo = ReadLine();

            Write(" From (USD, RUB, UAH, CHY, EUR): ");
            var currencyFrom = ReadLine();

            var fromCurrency = Customer.Wallets.Find(x => x.Currency.Name == currencyFrom?.ToUpper());
            var toCurrency = Customer.Wallets.Find(x => x.Currency.Name == currencyTo?.ToUpper());

            if (fromCurrency != null && toCurrency != null)
            {
                CurrencyConvertor.ConvertCurrnecy(currencyTo, currencyFrom, ValidateMoney());
            }
            else
                WriteLine($"{currencyTo} or {currencyFrom} does not exist in your wallet.");
        }

        public static double ValidateMoney()
        {
            string money;

            while (true)
            {
                Write("Enter the amount of money: ");
                money = ReadLine();

                if (double.TryParse(money, out var userMoney))
                {
                    return userMoney;
                }
                else
                    WriteLine("You entered incorrect data.");
            }
        }

        public static void CreateMoneyAccount()
        {
            Write("Choose currency of your new account: USD, UAH, EUR, RUB, CNY: ");
            var newWalletCurrency = ReadLine();

            var selectedCurrency = CurrencyConvertor.Currencies.Find(x => x.Name == newWalletCurrency?.ToUpper());
            var newCurrency = Customer.Wallets.Find(x => x.Currency.Name == newWalletCurrency?.ToUpper());

            if (selectedCurrency != null && !Wallets.Contains(newCurrency))
            { 
                var newWallet = new Wallet(selectedCurrency, ValidateMoney());
                Wallets.Add(newWallet);
                WriteLine("The new account has been successfully created.");
            }
            else
                WriteLine($"{newWalletCurrency} does not exist in our bank or you already have wallet with this currency.");
        }

        public static void TopUpAccount()
        {
            WriteLine("Enter the currency of the account you want to fund: USD, UAH, EUR, RUB, CNY: ");
            var account = ReadLine();

            var selectedAccount = Customer.Wallets.Find(x => x.Currency.Name == account?.ToUpper());

            if (selectedAccount != null)
            {
                selectedAccount.Money += ValidateMoney();
                WriteLine($"You have {selectedAccount.Money} {selectedAccount.Currency.Name} in your account.");
            }
            else
                WriteLine($"{account} does not exist in your wallets.");
        }

        public static void WithdrawMoney()
        {
            WriteLine("Enter the currency of the account from which you want to withdraw money: ");
            var account = ReadLine();

            var selectedAccount = Customer.Wallets.Find(x => x.Currency.Name == account?.ToUpper());

            var moneyToWithdraw = ValidateMoney();
            if (selectedAccount != null)
            {
                if (selectedAccount.Money < moneyToWithdraw)
                    WriteLine("You don't have enough money");
                else
                {
                    selectedAccount.Money -= moneyToWithdraw;
                    WriteLine($"You have {selectedAccount.Money} {selectedAccount.Currency.Name} in your account.");
                }
            }
            else
                WriteLine($"{account} does not exist in your wallet.");
        }
    }
}
