﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Task1
{
    internal class CurrencyConvertor
    {
        public static List<Currency> Currencies = new List<Currency>()
        {
            new Currency("USD", 27.939),
            new Currency("RUB", 0.3656),
            new Currency("EUR", 32.8632),
            new Currency("UAH", 1),
            new Currency("CHY", 4.2778)
        };

        public static void ConvertCurrnecy(string convertTo, string convertFrom, double amountOfMoney)
        {
            var selectedCurrencyTo = Customer.Wallets.Find(x => x.Currency.Name == convertTo?.ToUpper());
            var selectedCurrencyFrom = Customer.Wallets.Find(x => x.Currency.Name == convertFrom?.ToUpper());
            if (selectedCurrencyTo != null && selectedCurrencyFrom != null)
            {
                var newMoney = amountOfMoney * selectedCurrencyFrom.Currency.Rate / selectedCurrencyTo.Currency.Rate;
                WriteLine($"{newMoney}");

                selectedCurrencyFrom.Money -= amountOfMoney;
                selectedCurrencyTo.Money += newMoney;

                WriteLine($"You have {selectedCurrencyTo.Money}{selectedCurrencyTo.Currency.Name} on your account.");

            }
            else
                WriteLine($"There is no such currency in your wallets.");
        }

        public static void ShowAllRates()
        {
            WriteLine("Name | Rate (for UAH)");

            foreach (var currency in Currencies)
                WriteLine($"{currency.Name} | currency.Rate");
        }
    }
}
